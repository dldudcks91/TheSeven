using System;
using UnityEngine;

/// <summary>
/// 캐릭터와 몬스터의 기본이 되는 추상 클래스
/// </summary>
public abstract class Entity : MonoBehaviour
{
    // 기본 정보
    [Header("Basic Info")]
    public string entityName;
    public int level = 1;
    
    // 기본 스탯
    [Header("Base Stats")]
    public float maxHp = 100f;
    public float currentHp;
    public float attackDamage = 10f;
    public float defense = 5f;
    public float attackSpeed = 1f; // 초당 공격 횟수
    public float evasion = 0.05f; // 5% 회피율
    public float criticalChance = 0.1f; // 10% 크리티컬 확률
    public float criticalDamage = 1.5f; // 150% 크리티컬 데미지
    
    // 전투 상태
    protected bool isDead = false;
    protected float attackTimer = 0f;
    
    // 이벤트
    public event Action<float, float> OnHpChanged; // (현재HP, 최대HP)
    public event Action<Entity> OnDeath;
    public event Action<float, bool> OnDamaged; // (데미지, 크리티컬 여부)
    public event Action OnAttack;
    
    protected virtual void Awake()
    {
        currentHp = maxHp;
    }
    
    protected virtual void Update()
    {
        if (isDead) return;
        
        // 공격 타이머 업데이트
        attackTimer += Time.deltaTime;
        
        if (attackTimer >= 1f / attackSpeed)
        {
            attackTimer = 0f;
            PerformAttack();
        }
    }
    
    /// <summary>
    /// 공격 수행 (자식 클래스에서 구현)
    /// </summary>
    protected abstract void PerformAttack();
    
    /// <summary>
    /// 데미지 받기
    /// </summary>
    public virtual void TakeDamage(float damage, Entity attacker)
    {
        if (isDead) return;
        
        // 회피 판정
        if (UnityEngine.Random.value < evasion)
        {
            Debug.Log($"{entityName} 회피!");
            return;
        }
        
        // 방어력 계산 (방어력이 높을수록 데미지 감소)
        float actualDamage = Mathf.Max(1, damage - defense);
        
        currentHp -= actualDamage;
        currentHp = Mathf.Max(0, currentHp);
        
        // 이벤트 발생
        OnHpChanged?.Invoke(currentHp, maxHp);
        OnDamaged?.Invoke(actualDamage, false);
        
        Debug.Log($"{entityName}이(가) {actualDamage} 데미지를 받았습니다. (남은 HP: {currentHp}/{maxHp})");
        
        // 사망 체크
        if (currentHp <= 0 && !isDead)
        {
            Die();
        }
    }
    
    /// <summary>
    /// 크리티컬 데미지 계산
    /// </summary>
    protected float CalculateDamage()
    {
        float damage = attackDamage;
        
        // 크리티컬 판정
        bool isCritical = UnityEngine.Random.value < criticalChance;
        if (isCritical)
        {
            damage *= criticalDamage;
            Debug.Log($"{entityName} 크리티컬 히트!");
        }
        
        return damage;
    }
    
    /// <summary>
    /// 사망 처리
    /// </summary>
    protected virtual void Die()
    {
        isDead = true;
        Debug.Log($"{entityName}이(가) 사망했습니다.");
        OnDeath?.Invoke(this);
    }
    
    /// <summary>
    /// HP 회복
    /// </summary>
    public virtual void Heal(float amount)
    {
        if (isDead) return;
        
        currentHp += amount;
        currentHp = Mathf.Min(currentHp, maxHp);
        
        OnHpChanged?.Invoke(currentHp, maxHp);
        Debug.Log($"{entityName}이(가) {amount} HP 회복. (현재 HP: {currentHp}/{maxHp})");
    }
    
    /// <summary>
    /// 부활
    /// </summary>
    public virtual void Revive()
    {
        isDead = false;
        currentHp = maxHp;
        attackTimer = 0f;
        OnHpChanged?.Invoke(currentHp, maxHp);
    }
    
    /// <summary>
    /// 스탯 업데이트 (장비 착용 등)
    /// </summary>
    public virtual void UpdateStats()
    {
        OnHpChanged?.Invoke(currentHp, maxHp);
    }
    
    // Getter
    public bool IsDead => isDead;
    public float GetHpPercentage() => maxHp > 0 ? currentHp / maxHp : 0;
}
