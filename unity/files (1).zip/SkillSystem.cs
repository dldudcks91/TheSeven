using System;
using UnityEngine;

/// <summary>
/// 스킬 타입
/// </summary>
public enum SkillType
{
    Damage,      // 데미지 스킬
    Heal,        // 힐 스킬
    Buff,        // 버프 스킬
    Debuff       // 디버프 스킬
}

/// <summary>
/// 스킬 데이터 (ScriptableObject로 만들 수도 있음)
/// </summary>
[Serializable]
public class Skill
{
    public string skillName;
    public SkillType skillType;
    public float activationChance; // 발동 확률 (0.0 ~ 1.0)
    public float damageMultiplier; // 공격력의 몇 배? (예: 2.0 = 200%)
    public float effectValue; // 힐량, 버프량 등
    public float effectDuration; // 효과 지속시간 (버프/디버프용)
    public string description;
    
    public Skill(string name, SkillType type, float chance, float multiplier, float value = 0f)
    {
        skillName = name;
        skillType = type;
        activationChance = chance;
        damageMultiplier = multiplier;
        effectValue = value;
    }
}

/// <summary>
/// 스킬 사용 컴포넌트
/// </summary>
public class SkillUser : MonoBehaviour
{
    [Header("Skill Settings")]
    public Skill[] skills;
    
    private Entity owner;
    
    private void Awake()
    {
        owner = GetComponent<Entity>();
    }
    
    /// <summary>
    /// 스킬 발동 시도 (평타 대신)
    /// </summary>
    /// <param name="target">공격 대상</param>
    /// <returns>스킬이 발동되었는지 여부</returns>
    public bool TryActivateSkill(Entity target)
    {
        if (skills == null || skills.Length == 0) return false;
        
        // 모든 스킬에 대해 확률 체크
        foreach (var skill in skills)
        {
            if (UnityEngine.Random.value < skill.activationChance)
            {
                ExecuteSkill(skill, target);
                return true;
            }
        }
        
        return false;
    }
    
    /// <summary>
    /// 스킬 실행
    /// </summary>
    private void ExecuteSkill(Skill skill, Entity target)
    {
        Debug.Log($"{owner.entityName}이(가) [{skill.skillName}] 스킬을 사용했습니다!");
        
        switch (skill.skillType)
        {
            case SkillType.Damage:
                ExecuteDamageSkill(skill, target);
                break;
                
            case SkillType.Heal:
                ExecuteHealSkill(skill);
                break;
                
            case SkillType.Buff:
                ExecuteBuffSkill(skill);
                break;
                
            case SkillType.Debuff:
                ExecuteDebuffSkill(skill, target);
                break;
        }
    }
    
    /// <summary>
    /// 데미지 스킬 실행
    /// </summary>
    private void ExecuteDamageSkill(Skill skill, Entity target)
    {
        if (target == null || target.IsDead) return;
        
        float damage = owner.attackDamage * skill.damageMultiplier;
        
        // 크리티컬 판정
        bool isCritical = UnityEngine.Random.value < owner.criticalChance;
        if (isCritical)
        {
            damage *= owner.criticalDamage;
            Debug.Log($"크리티컬 스킬 히트!");
        }
        
        target.TakeDamage(damage, owner);
        Debug.Log($"스킬 데미지: {damage}");
    }
    
    /// <summary>
    /// 힐 스킬 실행
    /// </summary>
    private void ExecuteHealSkill(Skill skill)
    {
        float healAmount = skill.effectValue;
        owner.Heal(healAmount);
    }
    
    /// <summary>
    /// 버프 스킬 실행
    /// </summary>
    private void ExecuteBuffSkill(Skill skill)
    {
        // TODO: 버프 시스템 구현
        Debug.Log($"버프 효과: {skill.effectValue}, 지속시간: {skill.effectDuration}초");
    }
    
    /// <summary>
    /// 디버프 스킬 실행
    /// </summary>
    private void ExecuteDebuffSkill(Skill skill, Entity target)
    {
        // TODO: 디버프 시스템 구현
        Debug.Log($"{target.entityName}에게 디버프 효과: {skill.effectValue}, 지속시간: {skill.effectDuration}초");
    }
    
    /// <summary>
    /// 스킬 추가
    /// </summary>
    public void AddSkill(Skill skill)
    {
        if (skills == null)
        {
            skills = new Skill[] { skill };
        }
        else
        {
            Skill[] newSkills = new Skill[skills.Length + 1];
            skills.CopyTo(newSkills, 0);
            newSkills[skills.Length] = skill;
            skills = newSkills;
        }
    }
}
