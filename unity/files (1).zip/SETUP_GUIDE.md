# Unity Idle RPG - 설정 가이드

## 📦 프로젝트 구조

```
Assets/
├── Scripts/
│   ├── Core/
│   │   ├── Entity.cs
│   │   ├── Character.cs
│   │   ├── Monster.cs
│   │   └── SkillSystem.cs
│   ├── Managers/
│   │   ├── GameManager.cs
│   │   ├── BattleManager.cs
│   │   ├── DataManager.cs
│   │   └── SaveManager.cs
│   ├── Items/
│   │   └── Equipment.cs
│   └── UI/
│       └── BattleUI.cs
├── Resources/
│   └── Data/
│       ├── monster-info.csv
│       ├── monster-score-config.csv
│       ├── item-rarity-config.csv
│       └── equipment-base.csv
└── Scenes/
    └── BattleScene.unity
```

## 🎮 Unity 씬 설정 방법

### 1. 빈 씬 생성
- File > New Scene
- 이름: "BattleScene"

### 2. GameManager 오브젝트 생성
```
1. 빈 GameObject 생성 (우클릭 > Create Empty)
2. 이름: "GameManager"
3. 컴포넌트 추가:
   - GameManager.cs
   - DataManager.cs
   - SaveManager.cs
```

### 3. BattleManager 오브젝트 생성
```
1. 빈 GameObject 생성
2. 이름: "BattleManager"
3. 컴포넌트 추가:
   - BattleManager.cs
```

### 4. Player 오브젝트 생성
```
1. 3D Object > Capsule (또는 Sprite로 2D 캐릭터)
2. 이름: "Player"
3. 컴포넌트 추가:
   - Character.cs
   - SkillUser.cs
4. Inspector에서 설정:
   - Entity Name: "용사"
   - Level: 1
   - Max HP: 100
   - Attack Damage: 10
   - Defense: 5
   - Attack Speed: 1
```

### 5. UI Canvas 생성
```
1. UI > Canvas
2. Canvas Scaler 설정:
   - UI Scale Mode: Scale With Screen Size
   - Reference Resolution: 1920x1080

3. Canvas 하위에 UI 요소 추가:

   Player Panel (좌측 상단):
   ├── PlayerName (Text)
   ├── PlayerLevel (Text)
   ├── PlayerHPBar (Slider)
   └── PlayerHPText (Text)

   Monster Panel (우측 상단):
   ├── MonsterName (Text)
   ├── MonsterLevel (Text)
   ├── MonsterHPBar (Slider)
   └── MonsterHPText (Text)

   Info Panel (하단):
   ├── GoldText (Text)
   ├── ExpText (Text)
   └── BattleLog (Text)

4. UI 매니저 오브젝트:
   - Canvas에 BattleUI.cs 컴포넌트 추가
   - Inspector에서 각 UI 요소 연결
```

## 📝 CSV 데이터 준비

### Resources/Data 폴더에 CSV 파일 배치

1. **monster-info.csv**
```csv
monster_idx,monster_name,monster_type,monster_sub_type,monster_class,hp,attack,defense,attack_speed,exp_reward
1,Gray Wolf,Beast,Wolf,1,250,30,10,1.2,50
2,Alpha Wolf,Beast,Wolf,2,800,60,25,1.5,200
3,Dire Wolf,Beast,Wolf,3,1500,95,40,1.6,400
```

2. **monster-score-config.csv**
```csv
param_name,value,description,category
field_level_multiplier,2.0,필드레벨이 베이스 점수에 곱해지는 값,base_calculation
level_growth_rate,0.01,몬스터 레벨 1당 스코어 증가율,multiplier
min_base_score,5,최소 베이스 점수 보정값,base_calculation
score_variance,0.05,스코어 랜덤 변동폭,randomness
```

3. **item-rarity-config.csv**
```csv
rarity,rarity_korean,min_score,max_score,base_weight,prefix_count,suffix_count,option_min,option_max,color_hex,description
normal,일반,0,50,1000,0,0,0,0,#FFFFFF,흰색 - 기본 아이템
magic,매직,30,200,500,1,0,1,3,#4169E1,파란색 - 접두사 1개
rare,레어,150,800,200,1,1,2,6,#FFD700,노란색 - 접두사+접미사
unique,유니크,500,99999,10,0,0,0,0,#FF8C00,주황색 - 고정 옵션
```

## ▶️ 실행 방법

### 게임 시작 흐름
```
1. GameManager가 자동으로 DataManager 초기화
2. DataManager가 CSV 파일들을 로드
3. GameManager가 첫 번째 몬스터 생성
4. BattleManager가 전투 시작
5. 자동으로 전투 진행
```

### 테스트 스크립트 (선택사항)
```csharp
// TestScript.cs - 테스트용 스크립트
using UnityEngine;

public class TestScript : MonoBehaviour
{
    void Start()
    {
        // 게임 매니저 찾기
        GameManager gameManager = GameManager.Instance;
        
        if (gameManager != null)
        {
            Debug.Log("게임 매니저 초기화 완료");
        }
    }
    
    void Update()
    {
        // R키로 게임 리셋
        if (Input.GetKeyDown(KeyCode.R))
        {
            GameManager.Instance.NewGame();
        }
        
        // S키로 저장
        if (Input.GetKeyDown(KeyCode.S))
        {
            GameManager.Instance.SaveGame();
        }
        
        // L키로 로드
        if (Input.GetKeyDown(KeyCode.L))
        {
            GameManager.Instance.LoadGame();
        }
        
        // P키로 일시정지
        if (Input.GetKeyDown(KeyCode.P))
        {
            GameManager gameManager = GameManager.Instance;
            if (gameManager.IsGamePaused())
                gameManager.ResumeGame();
            else
                gameManager.PauseGame();
        }
    }
}
```

## 🔧 추가 설정

### TextMeshPro 사용 시
1. Window > TextMeshPro > Import TMP Essential Resources
2. UI Text 대신 TextMeshProUGUI 사용

### 모바일 빌드 설정
```
1. File > Build Settings
2. Platform: Android 또는 iOS 선택
3. Switch Platform
4. Player Settings:
   - Company Name 설정
   - Product Name: "Idle RPG"
   - Bundle Identifier 설정
   - Orientation: Portrait
```

## 🎨 권장 에셋

### 필수
- TextMeshPro (Unity 기본 제공)

### 선택
- 2D 스프라이트: Unity Asset Store에서 무료 캐릭터 팩
- UI 이펙트: Particle System
- 사운드: 공격 사운드, 레벨업 사운드 등

## 🐛 디버깅 팁

### Console 로그 확인
- Window > General > Console
- 전투 로그가 실시간으로 출력됨

### Inspector에서 실시간 확인
- Play 모드에서 Character/Monster의 HP, 스탯 등을 실시간으로 확인 가능

### 주요 체크포인트
1. GameManager에서 Player 레퍼런스가 연결되었는지
2. BattleUI에서 모든 UI 요소가 연결되었는지
3. Resources/Data 폴더에 CSV 파일이 있는지

## 📱 모바일 최적화

### 성능 설정
```csharp
// GameManager.cs에서 이미 설정됨
Application.targetFrameRate = 60;
```

### 해상도 설정
```csharp
// 필요시 추가
Screen.SetResolution(1920, 1080, true);
```

## 🚀 다음 단계

1. **아이템 드랍 시스템 완성**
   - ItemDropManager 구현
   - 실제 아이템 생성 로직

2. **인벤토리 시스템**
   - InventoryManager 구현
   - 아이템 장착/해제 UI

3. **스킬 시스템 확장**
   - 더 다양한 스킬 타입
   - 스킬 애니메이션

4. **필드 시스템**
   - 여러 필드/지역
   - 필드별 몬스터 테이블

5. **강화 시스템**
   - 아이템 강화
   - 캐릭터 스탯 강화

## ⚠️ 주의사항

1. **CSV 파일 인코딩**: UTF-8로 저장
2. **Resources 폴더**: 반드시 Assets/Resources 경로에 있어야 함
3. **씬 저장**: 씬 설정 후 반드시 저장 (Ctrl+S)
4. **빌드 전**: 씬을 Build Settings에 추가

## 💡 팁

- Idle 게임이므로 Time.timeScale을 조절하여 게임 속도 조절 가능
- Auto Save는 30초마다 자동 실행
- 모바일에서 백그라운드로 갈 때 자동 저장됨
