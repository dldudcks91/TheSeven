using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// 전투 UI 관리
/// </summary>
public class BattleUI : MonoBehaviour
{
    [Header("Player UI")]
    public Slider playerHpBar;
    public TextMeshProUGUI playerNameText;
    public TextMeshProUGUI playerLevelText;
    public TextMeshProUGUI playerHpText;
    
    [Header("Monster UI")]
    public Slider monsterHpBar;
    public TextMeshProUGUI monsterNameText;
    public TextMeshProUGUI monsterLevelText;
    public TextMeshProUGUI monsterHpText;
    
    [Header("Info UI")]
    public TextMeshProUGUI goldText;
    public TextMeshProUGUI expText;
    public TextMeshProUGUI battleLogText;
    
    [Header("Damage Text")]
    public GameObject damageTextPrefab;
    public Transform playerDamageSpawn;
    public Transform monsterDamageSpawn;
    
    private Character player;
    private Monster currentMonster;
    private BattleManager battleManager;
    
    private void Start()
    {
        battleManager = BattleManager.Instance;
        
        if (battleManager != null)
        {
            battleManager.OnBattleStart += OnBattleStart;
            battleManager.OnMonsterDefeated += OnMonsterDefeated;
        }
        
        // 플레이어 찾기
        player = FindObjectOfType<Character>();
        if (player != null)
        {
            SetupPlayerUI();
        }
    }
    
    private void OnDestroy()
    {
        if (battleManager != null)
        {
            battleManager.OnBattleStart -= OnBattleStart;
            battleManager.OnMonsterDefeated -= OnMonsterDefeated;
        }
        
        if (player != null)
        {
            player.OnHpChanged -= UpdatePlayerHp;
            player.OnDamaged -= OnPlayerDamaged;
        }
        
        if (currentMonster != null)
        {
            currentMonster.OnHpChanged -= UpdateMonsterHp;
            currentMonster.OnDamaged -= OnMonsterDamaged;
        }
    }
    
    /// <summary>
    /// 플레이어 UI 설정
    /// </summary>
    private void SetupPlayerUI()
    {
        player.OnHpChanged += UpdatePlayerHp;
        player.OnDamaged += OnPlayerDamaged;
        
        if (playerNameText != null)
            playerNameText.text = player.entityName;
        
        UpdatePlayerLevel();
        UpdatePlayerHp(player.currentHp, player.maxHp);
        UpdateGold();
        UpdateExp();
    }
    
    /// <summary>
    /// 전투 시작 이벤트
    /// </summary>
    private void OnBattleStart(Monster monster)
    {
        // 이전 몬스터 이벤트 해제
        if (currentMonster != null)
        {
            currentMonster.OnHpChanged -= UpdateMonsterHp;
            currentMonster.OnDamaged -= OnMonsterDamaged;
        }
        
        currentMonster = monster;
        
        // 몬스터 이벤트 등록
        currentMonster.OnHpChanged += UpdateMonsterHp;
        currentMonster.OnDamaged += OnMonsterDamaged;
        
        // 몬스터 UI 업데이트
        if (monsterNameText != null)
            monsterNameText.text = monster.entityName;
        
        if (monsterLevelText != null)
            monsterLevelText.text = $"Lv.{monster.level}";
        
        UpdateMonsterHp(monster.currentHp, monster.maxHp);
        
        AddBattleLog($"<color=red>{monster.entityName}</color> 출현!");
    }
    
    /// <summary>
    /// 몬스터 처치 이벤트
    /// </summary>
    private void OnMonsterDefeated(Monster monster)
    {
        AddBattleLog($"<color=green>{monster.entityName} 처치!</color>");
        AddBattleLog($"경험치 +{monster.expReward}, 골드 +{monster.goldReward}");
        
        UpdateGold();
        UpdateExp();
        UpdatePlayerLevel();
    }
    
    /// <summary>
    /// 플레이어 HP 업데이트
    /// </summary>
    private void UpdatePlayerHp(float current, float max)
    {
        if (playerHpBar != null)
        {
            playerHpBar.value = current / max;
        }
        
        if (playerHpText != null)
        {
            playerHpText.text = $"{Mathf.RoundToInt(current)} / {Mathf.RoundToInt(max)}";
        }
    }
    
    /// <summary>
    /// 몬스터 HP 업데이트
    /// </summary>
    private void UpdateMonsterHp(float current, float max)
    {
        if (monsterHpBar != null)
        {
            monsterHpBar.value = current / max;
        }
        
        if (monsterHpText != null)
        {
            monsterHpText.text = $"{Mathf.RoundToInt(current)} / {Mathf.RoundToInt(max)}";
        }
    }
    
    /// <summary>
    /// 플레이어 레벨 업데이트
    /// </summary>
    private void UpdatePlayerLevel()
    {
        if (player == null) return;
        
        if (playerLevelText != null)
        {
            playerLevelText.text = $"Lv.{player.level}";
        }
    }
    
    /// <summary>
    /// 골드 업데이트
    /// </summary>
    private void UpdateGold()
    {
        if (player == null || goldText == null) return;
        
        goldText.text = $"Gold: {player.gold}";
    }
    
    /// <summary>
    /// 경험치 업데이트
    /// </summary>
    private void UpdateExp()
    {
        if (player == null || expText == null) return;
        
        expText.text = $"EXP: {player.exp} / {player.expToNextLevel}";
    }
    
    /// <summary>
    /// 플레이어 피격 시
    /// </summary>
    private void OnPlayerDamaged(float damage, bool isCritical)
    {
        ShowDamageText(playerDamageSpawn.position, damage, isCritical, false);
    }
    
    /// <summary>
    /// 몬스터 피격 시
    /// </summary>
    private void OnMonsterDamaged(float damage, bool isCritical)
    {
        ShowDamageText(monsterDamageSpawn.position, damage, isCritical, true);
    }
    
    /// <summary>
    /// 데미지 텍스트 표시
    /// </summary>
    private void ShowDamageText(Vector3 position, float damage, bool isCritical, bool isPlayerDamage)
    {
        if (damageTextPrefab == null) return;
        
        GameObject damageObj = Instantiate(damageTextPrefab, position, Quaternion.identity, transform);
        TextMeshProUGUI damageText = damageObj.GetComponent<TextMeshProUGUI>();
        
        if (damageText != null)
        {
            string text = Mathf.RoundToInt(damage).ToString();
            
            if (isCritical)
            {
                text = $"<size=150%>{text}!</size>";
                damageText.color = Color.yellow;
            }
            else
            {
                damageText.color = isPlayerDamage ? Color.white : Color.red;
            }
            
            damageText.text = text;
        }
        
        // 2초 후 삭제
        Destroy(damageObj, 2f);
    }
    
    /// <summary>
    /// 전투 로그 추가
    /// </summary>
    private void AddBattleLog(string message)
    {
        if (battleLogText == null) return;
        
        // 최대 10줄만 유지
        string[] lines = battleLogText.text.Split('\n');
        if (lines.Length >= 10)
        {
            battleLogText.text = string.Join("\n", lines, 1, lines.Length - 1);
        }
        
        battleLogText.text += message + "\n";
    }
    
    /// <summary>
    /// UI 업데이트 (매 프레임)
    /// </summary>
    private void Update()
    {
        // 실시간으로 업데이트가 필요한 UI가 있다면 여기서 처리
    }
}
