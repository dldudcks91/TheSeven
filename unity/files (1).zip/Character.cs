using UnityEngine;

/// <summary>
/// 플레이어 캐릭터
/// </summary>
public class Character : Entity
{
    [Header("Character Specific")]
    public int exp = 0;
    public int expToNextLevel = 100;
    public int gold = 0;
    
    [Header("Equipment")]
    public Equipment weapon;
    public Equipment armor;
    public Equipment helmet;
    public Equipment gloves;
    public Equipment boots;
    
    private SkillUser skillUser;
    private Entity currentTarget;
    
    protected override void Awake()
    {
        base.Awake();
        skillUser = GetComponent<SkillUser>();
        
        // 기본 스킬 설정 (테스트용)
        if (skillUser != null)
        {
            // 강타 스킬: 10% 확률로 200% 데미지
            skillUser.AddSkill(new Skill("강타", SkillType.Damage, 0.1f, 2.0f));
            
            // 연타 스킬: 5% 확률로 150% 데미지 3연속
            skillUser.AddSkill(new Skill("연타", SkillType.Damage, 0.05f, 1.5f));
        }
    }
    
    /// <summary>
    /// 공격 대상 설정
    /// </summary>
    public void SetTarget(Entity target)
    {
        currentTarget = target;
    }
    
    /// <summary>
    /// 공격 수행
    /// </summary>
    protected override void PerformAttack()
    {
        if (currentTarget == null || currentTarget.IsDead)
        {
            Debug.Log("공격할 대상이 없습니다.");
            return;
        }
        
        OnAttack?.Invoke();
        
        // 스킬 발동 시도
        if (skillUser != null && skillUser.TryActivateSkill(currentTarget))
        {
            // 스킬이 발동되면 평타는 하지 않음
            return;
        }
        
        // 일반 공격
        float damage = CalculateDamage();
        currentTarget.TakeDamage(damage, this);
    }
    
    /// <summary>
    /// 경험치 획득
    /// </summary>
    public void GainExp(int amount)
    {
        exp += amount;
        Debug.Log($"경험치 획득: +{amount} (현재: {exp}/{expToNextLevel})");
        
        // 레벨업 체크
        while (exp >= expToNextLevel)
        {
            LevelUp();
        }
    }
    
    /// <summary>
    /// 레벨업
    /// </summary>
    private void LevelUp()
    {
        level++;
        exp -= expToNextLevel;
        
        // 스탯 증가
        maxHp += 20f;
        attackDamage += 5f;
        defense += 2f;
        
        // 다음 레벨 경험치 증가
        expToNextLevel = Mathf.RoundToInt(expToNextLevel * 1.2f);
        
        // HP 회복
        currentHp = maxHp;
        
        Debug.Log($"레벨업! Lv.{level} (다음 레벨까지: {expToNextLevel} exp)");
        OnHpChanged?.Invoke(currentHp, maxHp);
    }
    
    /// <summary>
    /// 골드 획득
    /// </summary>
    public void GainGold(int amount)
    {
        gold += amount;
        Debug.Log($"골드 획득: +{amount} (현재: {gold})");
    }
    
    /// <summary>
    /// 장비 착용
    /// </summary>
    public void EquipItem(Equipment equipment)
    {
        if (equipment == null) return;
        
        // 기존 장비 해제
        UnequipItem(equipment.equipmentType);
        
        // 새 장비 착용
        switch (equipment.equipmentType)
        {
            case EquipmentType.Weapon:
                weapon = equipment;
                break;
            case EquipmentType.Armor:
                armor = equipment;
                break;
            case EquipmentType.Helmet:
                helmet = equipment;
                break;
            case EquipmentType.Gloves:
                gloves = equipment;
                break;
            case EquipmentType.Boots:
                boots = equipment;
                break;
        }
        
        Debug.Log($"{equipment.itemName} 착용");
        RecalculateStats();
    }
    
    /// <summary>
    /// 장비 해제
    /// </summary>
    public void UnequipItem(EquipmentType type)
    {
        switch (type)
        {
            case EquipmentType.Weapon:
                weapon = null;
                break;
            case EquipmentType.Armor:
                armor = null;
                break;
            case EquipmentType.Helmet:
                helmet = null;
                break;
            case EquipmentType.Gloves:
                gloves = null;
                break;
            case EquipmentType.Boots:
                boots = null;
                break;
        }
        
        RecalculateStats();
    }
    
    /// <summary>
    /// 장비 효과를 반영한 스탯 재계산
    /// </summary>
    private void RecalculateStats()
    {
        // 기본 스탯 (레벨 기반)
        float baseHp = 100f + (level - 1) * 20f;
        float baseAtk = 10f + (level - 1) * 5f;
        float baseDef = 5f + (level - 1) * 2f;
        
        // 장비 보너스 적용
        Equipment[] equipments = { weapon, armor, helmet, gloves, boots };
        
        float bonusHp = 0f;
        float bonusAtk = 0f;
        float bonusDef = 0f;
        float bonusAtkSpeed = 0f;
        float bonusEvasion = 0f;
        float bonusCritChance = 0f;
        float bonusCritDamage = 0f;
        
        foreach (var eq in equipments)
        {
            if (eq == null) continue;
            
            // TODO: Equipment 스탯 적용
            // bonusAtk += eq.attackBonus;
            // bonusDef += eq.defenseBonus;
            // 등등...
        }
        
        // 최종 스탯 적용
        maxHp = baseHp + bonusHp;
        attackDamage = baseAtk + bonusAtk;
        defense = baseDef + bonusDef;
        attackSpeed = 1f + bonusAtkSpeed;
        evasion = 0.05f + bonusEvasion;
        criticalChance = 0.1f + bonusCritChance;
        criticalDamage = 1.5f + bonusCritDamage;
        
        // HP 비율 유지
        float hpRatio = currentHp / maxHp;
        currentHp = maxHp * hpRatio;
        
        UpdateStats();
    }
    
    /// <summary>
    /// 전투 준비 상태로 리셋
    /// </summary>
    public void ResetForBattle()
    {
        Revive();
        currentTarget = null;
        attackTimer = 0f;
    }
}
