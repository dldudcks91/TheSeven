# Unity Idle RPG - 코드 구조 및 확장 가이드

## 📐 아키텍처 개요

### 싱글톤 패턴
```
GameManager (메인 싱글톤)
└── BattleManager (전투 싱글톤)
```

### 상속 구조
```
Entity (추상 클래스)
├── Character (플레이어)
└── Monster (몬스터)
```

### 매니저 시스템
```
GameManager
├── DataManager (CSV 데이터)
├── SaveManager (저장/로드)
└── BattleManager (전투 로직)
```

## 🔄 게임 루프

### 메인 흐름
```
Awake()
└── GameManager 싱글톤 생성
    └── 하위 매니저 초기화

Start()
└── DataManager.LoadAllData()
    └── CSV 파일 로드
        
StartGame()
└── SaveManager.LoadPlayerData() 또는 NewGame()
    └── 첫 몬스터 생성
        └── BattleManager.StartBattle()

Update()
└── Entity.Update() (각 캐릭터/몬스터)
    └── attackTimer 업데이트
        └── PerformAttack()
            └── TakeDamage()
                └── HP 감소
                    └── Die() 이벤트
```

### 전투 사이클
```
1. StartBattle(monster)
   ↓
2. Player와 Monster가 서로를 타겟으로 설정
   ↓
3. 각자의 Update()에서 attackTimer 체크
   ↓
4. 공격 시간이 되면 PerformAttack()
   ↓
5. 스킬 발동 확률 체크 (TryActivateSkill)
   ↓
6. 스킬 실패 시 일반 공격
   ↓
7. 상대방의 TakeDamage() 호출
   ↓
8. HP가 0이 되면 Die() 호출
   ↓
9. Monster 사망 → 보상 지급 → 다음 몬스터
   Player 사망 → 부활 → 전투 재개
```

## 📊 데이터 플로우

### CSV → 게임
```
Resources/Data/monster-info.csv
└── DataManager.LoadMonsterData()
    └── Dictionary<int, MonsterData>
        └── DataManager.GetMonsterData(id)
            └── Monster.Initialize(data)
```

### 게임 → 저장
```
Character (현재 상태)
└── SaveManager.SavePlayerData()
    └── SaveData (직렬화)
        └── JSON 변환
            └── File.WriteAllText()
```

## 🎯 주요 이벤트 시스템

### Entity 이벤트
```csharp
// HP 변경
OnHpChanged?.Invoke(currentHp, maxHp);

// 데미지 받음
OnDamaged?.Invoke(damage, isCritical);

// 사망
OnDeath?.Invoke(this);

// 공격
OnAttack?.Invoke();
```

### BattleManager 이벤트
```csharp
// 전투 시작
OnBattleStart?.Invoke(monster);

// 몬스터 처치
OnMonsterDefeated?.Invoke(monster);

// 플레이어 사망
OnPlayerDefeated?.Invoke();

// 전투 상태 변경
OnBattleStateChanged?.Invoke(newState);
```

## 🔧 확장 포인트

### 1. 새로운 스킬 추가
```csharp
// SkillSystem.cs에서 SkillType enum 확장
public enum SkillType
{
    Damage,
    Heal,
    Buff,
    Debuff,
    Summon,      // 새로운 타입
    Transform    // 새로운 타입
}

// ExecuteSkill에서 케이스 추가
case SkillType.Summon:
    ExecuteSummonSkill(skill);
    break;
```

### 2. 새로운 스탯 추가
```csharp
// Equipment.cs에서 StatType enum 확장
public enum StatType
{
    // ... 기존 스탯
    MagicPower,        // 새로운 스탯
    ManaRegeneration   // 새로운 스탯
}

// Character.cs에서 스탯 변수 추가
public float magicPower = 0f;
public float manaRegeneration = 0f;

// RecalculateStats()에서 계산 로직 추가
```

### 3. 아이템 드랍 시스템 추가
```csharp
// ItemDropManager.cs (새로 만들기)
public class ItemDropManager : MonoBehaviour
{
    public Equipment GenerateItem(float monsterScore)
    {
        // 1. Rarity 결정
        RarityConfig rarity = DataManager.GetRarityConfigForScore(monsterScore);
        
        // 2. 장비 타입 결정
        EquipmentType type = DetermineEquipmentType();
        
        // 3. 베이스 아이템 선택
        EquipmentBaseData baseData = SelectBaseEquipment(type);
        
        // 4. 품질 결정 (베타분포)
        float quality = CalculateQuality(monsterScore);
        
        // 5. 접두/접미사 선택
        string prefix = SelectPrefix(type, rarity);
        string suffix = SelectSuffix(type, rarity);
        
        // 6. 옵션 생성
        List<ItemOption> options = GenerateOptions(rarity, monsterScore);
        
        // 7. 아이템 빌드
        Equipment item = new EquipmentBuilder(baseData.itemIdx, baseData.itemBase, type)
            .SetLevel(CalculateItemLevel(monsterScore))
            .SetRarity(rarity.rarity)
            .SetQuality(quality)
            .SetPrefix(prefix)
            .SetSuffix(suffix)
            .Build();
        
        foreach (var option in options)
        {
            item.AddOption(option);
        }
        
        return item;
    }
}
```

### 4. 인벤토리 시스템 추가
```csharp
// InventoryManager.cs (새로 만들기)
public class InventoryManager : MonoBehaviour
{
    [SerializeField] private int maxSlots = 50;
    private List<Equipment> items = new List<Equipment>();
    
    public bool AddItem(Equipment item)
    {
        if (items.Count >= maxSlots)
        {
            Debug.Log("인벤토리가 가득 찼습니다!");
            return false;
        }
        
        items.Add(item);
        OnItemAdded?.Invoke(item);
        return true;
    }
    
    public void RemoveItem(Equipment item)
    {
        items.Remove(item);
        OnItemRemoved?.Invoke(item);
    }
    
    public event Action<Equipment> OnItemAdded;
    public event Action<Equipment> OnItemRemoved;
}
```

### 5. 강화 시스템 추가
```csharp
// EnhancementSystem.cs (새로 만들기)
public class EnhancementSystem : MonoBehaviour
{
    public bool EnhanceEquipment(Equipment equipment, int targetLevel)
    {
        int currentLevel = equipment.enhanceLevel;
        
        if (currentLevel >= targetLevel)
            return false;
        
        // 강화 확률 계산
        float successRate = CalculateSuccessRate(currentLevel);
        
        // 강화 비용 계산
        int cost = CalculateEnhanceCost(currentLevel);
        
        if (player.gold < cost)
            return false;
        
        // 골드 차감
        player.gold -= cost;
        
        // 성공 판정
        if (UnityEngine.Random.value < successRate)
        {
            equipment.enhanceLevel++;
            ApplyEnhanceBonus(equipment);
            Debug.Log($"강화 성공! +{equipment.enhanceLevel}");
            return true;
        }
        else
        {
            Debug.Log("강화 실패!");
            // 실패 시 장비 파괴 또는 레벨 하락
            return false;
        }
    }
}
```

## 🎮 Unity 컴포넌트 패턴

### MonoBehaviour vs ScriptableObject

#### MonoBehaviour (현재 사용)
```csharp
// 씬에 존재하는 오브젝트
public class Character : Entity { }
public class Monster : Entity { }
```

**장점:**
- Update(), Coroutine 사용 가능
- Transform, 물리 등 Unity 기능 사용
- 씬에서 직접 배치/테스트 가능

#### ScriptableObject (권장 - 데이터용)
```csharp
// 아이템, 스킬 등 데이터에 적합
[CreateAssetMenu(fileName = "NewSkill", menuName = "Game/Skill")]
public class SkillData : ScriptableObject
{
    public string skillName;
    public SkillType skillType;
    public float activationChance;
    // ...
}
```

**장점:**
- 메모리 효율적 (인스턴스 공유)
- 에디터에서 쉽게 관리
- 프리팹보다 가벼움

## 🔍 디버깅 전략

### 로그 레벨 시스템
```csharp
public enum LogLevel
{
    None,
    Error,
    Warning,
    Info,
    Debug
}

public class GameLogger
{
    public static LogLevel currentLevel = LogLevel.Info;
    
    public static void Log(string message, LogLevel level = LogLevel.Info)
    {
        if (level <= currentLevel)
        {
            Debug.Log($"[{level}] {message}");
        }
    }
}
```

### 디버그 UI
```csharp
public class DebugUI : MonoBehaviour
{
    private bool showDebug = false;
    
    void OnGUI()
    {
        if (!showDebug) return;
        
        GUI.Box(new Rect(10, 10, 300, 200), "Debug Info");
        
        GUILayout.BeginArea(new Rect(20, 40, 280, 160));
        
        GUILayout.Label($"FPS: {1f / Time.deltaTime:F0}");
        GUILayout.Label($"Player HP: {player.currentHp}/{player.maxHp}");
        GUILayout.Label($"Monster HP: {monster.currentHp}/{monster.maxHp}");
        GUILayout.Label($"Battle State: {battleManager.GetBattleState()}");
        
        if (GUILayout.Button("Kill Monster"))
        {
            monster.TakeDamage(999999, player);
        }
        
        if (GUILayout.Button("Heal Player"))
        {
            player.Heal(9999);
        }
        
        GUILayout.EndArea();
    }
    
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.F1))
        {
            showDebug = !showDebug;
        }
    }
}
```

## ⚡ 최적화 팁

### 1. Object Pooling (데미지 텍스트용)
```csharp
public class DamageTextPool : MonoBehaviour
{
    public GameObject damageTextPrefab;
    private Queue<GameObject> pool = new Queue<GameObject>();
    
    public GameObject Get()
    {
        if (pool.Count > 0)
        {
            GameObject obj = pool.Dequeue();
            obj.SetActive(true);
            return obj;
        }
        
        return Instantiate(damageTextPrefab);
    }
    
    public void Return(GameObject obj)
    {
        obj.SetActive(false);
        pool.Enqueue(obj);
    }
}
```

### 2. Update 최적화
```csharp
// 매 프레임 말고 N프레임마다 실행
private int updateInterval = 5;
private int frameCount = 0;

void Update()
{
    frameCount++;
    
    if (frameCount % updateInterval == 0)
    {
        // 덜 중요한 업데이트
        UpdateUI();
    }
}
```

### 3. 이벤트 구독 해제
```csharp
void OnDestroy()
{
    // 반드시 이벤트 구독 해제!
    player.OnHpChanged -= UpdatePlayerHp;
    monster.OnDeath -= OnMonsterDeath;
}
```

## 📱 모바일 최적화

### 터치 입력
```csharp
void Update()
{
    if (Input.touchCount > 0)
    {
        Touch touch = Input.GetTouch(0);
        
        if (touch.phase == TouchPhase.Began)
        {
            // 터치 시작
            OnTouchBegan(touch.position);
        }
    }
}
```

### 배터리 절약
```csharp
void OnApplicationPause(bool pause)
{
    if (pause)
    {
        // 백그라운드로 갈 때
        Time.timeScale = 0f;
        Application.targetFrameRate = 10; // 프레임 낮춤
    }
    else
    {
        // 포그라운드로 돌아올 때
        Time.timeScale = 1f;
        Application.targetFrameRate = 60;
    }
}
```

## 🎨 UI 애니메이션 추가

### DOTween 예제 (선택)
```csharp
using DG.Tweening;

public void ShowDamageText(float damage)
{
    damageText.text = damage.ToString();
    damageText.transform.localScale = Vector3.zero;
    
    damageText.transform.DOScale(1f, 0.3f)
        .SetEase(Ease.OutBack);
    
    damageText.transform.DOMoveY(100f, 1f)
        .SetRelative()
        .OnComplete(() => Destroy(damageText.gameObject));
}
```

## 📦 권장 폴더 구조

```
Assets/
├── Scripts/
│   ├── Core/           # Entity, Character, Monster
│   ├── Managers/       # GameManager, BattleManager 등
│   ├── Items/          # Equipment, Item
│   ├── UI/             # BattleUI, InventoryUI
│   ├── Utils/          # 유틸리티 함수들
│   └── Data/           # 데이터 클래스들
├── Resources/
│   └── Data/           # CSV 파일들
├── Prefabs/
│   ├── UI/             # UI 프리팹
│   ├── Characters/     # 캐릭터 프리팹
│   └── Effects/        # 이펙트 프리팹
├── Scenes/
├── Sprites/            # 2D 이미지
└── Audio/              # 사운드 파일
```

이 구조를 따르면 나중에 팀 작업이나 대규모 확장에도 유리합니다!
