using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// 게임 전체를 관리하는 매니저
/// </summary>
public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }
    
    [Header("Game Settings")]
    public int targetFrameRate = 60;
    public bool isAutoPlay = true; // Idle 게임은 기본적으로 자동 진행
    
    [Header("References")]
    public Character player;
    
    // 하위 매니저들
    private DataManager dataManager;
    private BattleManager battleManager;
    private SaveManager saveManager;
    
    // 게임 상태
    private bool isGamePaused = false;
    private float gamePlayTime = 0f;
    
    private void Awake()
    {
        // 싱글톤 설정
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
            return;
        }
        
        // 프레임레이트 설정
        Application.targetFrameRate = targetFrameRate;
        
        // 매니저 초기화
        InitializeManagers();
    }
    
    private void Start()
    {
        // 게임 시작
        StartGame();
    }
    
    private void Update()
    {
        if (!isGamePaused)
        {
            gamePlayTime += Time.deltaTime;
            
            // 자동 저장 (30초마다)
            if (gamePlayTime % 30f < Time.deltaTime)
            {
                AutoSave();
            }
        }
    }
    
    /// <summary>
    /// 매니저 초기화
    /// </summary>
    private void InitializeManagers()
    {
        // DataManager
        dataManager = GetComponent<DataManager>();
        if (dataManager == null)
        {
            dataManager = gameObject.AddComponent<DataManager>();
        }
        
        // BattleManager
        battleManager = FindObjectOfType<BattleManager>();
        if (battleManager == null)
        {
            GameObject battleObj = new GameObject("BattleManager");
            battleManager = battleObj.AddComponent<BattleManager>();
        }
        
        // SaveManager
        saveManager = GetComponent<SaveManager>();
        if (saveManager == null)
        {
            saveManager = gameObject.AddComponent<SaveManager>();
        }
    }
    
    /// <summary>
    /// 게임 시작
    /// </summary>
    public void StartGame()
    {
        Debug.Log("===== 게임 시작 =====");
        
        // 데이터 로드
        if (dataManager != null)
        {
            dataManager.LoadAllData();
        }
        
        // 저장 데이터 로드 시도
        if (saveManager != null && saveManager.HasSaveData())
        {
            LoadGame();
        }
        else
        {
            // 새 게임
            NewGame();
        }
    }
    
    /// <summary>
    /// 새 게임
    /// </summary>
    public void NewGame()
    {
        Debug.Log("새 게임 시작");
        
        // 플레이어 초기화
        if (player != null)
        {
            player.level = 1;
            player.exp = 0;
            player.gold = 100; // 시작 골드
            player.currentHp = player.maxHp;
        }
        
        // 첫 몬스터와 전투 시작
        if (battleManager != null && dataManager != null)
        {
            MonsterData firstMonster = dataManager.GetMonsterData(1); // ID 1번 몬스터
            if (firstMonster != null)
            {
                SpawnAndFightMonster(firstMonster);
            }
        }
    }
    
    /// <summary>
    /// 게임 저장
    /// </summary>
    public void SaveGame()
    {
        if (saveManager != null && player != null)
        {
            saveManager.SavePlayerData(player);
            Debug.Log("게임 저장 완료");
        }
    }
    
    /// <summary>
    /// 게임 로드
    /// </summary>
    public void LoadGame()
    {
        if (saveManager != null && player != null)
        {
            saveManager.LoadPlayerData(player);
            Debug.Log("게임 로드 완료");
            
            // 전투 재개
            // TODO: 저장된 몬스터 정보도 로드
        }
    }
    
    /// <summary>
    /// 자동 저장
    /// </summary>
    private void AutoSave()
    {
        SaveGame();
        Debug.Log("자동 저장");
    }
    
    /// <summary>
    /// 몬스터 생성 및 전투 시작
    /// </summary>
    public void SpawnAndFightMonster(MonsterData data)
    {
        // 몬스터 생성
        GameObject monsterObj = new GameObject($"Monster_{data.monsterName}");
        Monster monster = monsterObj.AddComponent<Monster>();
        monster.AddComponent<SkillUser>();
        
        // 몬스터 초기화
        monster.Initialize(data);
        
        // 전투 시작
        if (battleManager != null)
        {
            battleManager.StartBattle(monster);
        }
    }
    
    /// <summary>
    /// 게임 일시정지
    /// </summary>
    public void PauseGame()
    {
        isGamePaused = true;
        Time.timeScale = 0f;
        Debug.Log("게임 일시정지");
    }
    
    /// <summary>
    /// 게임 재개
    /// </summary>
    public void ResumeGame()
    {
        isGamePaused = false;
        Time.timeScale = 1f;
        Debug.Log("게임 재개");
    }
    
    /// <summary>
    /// 게임 종료
    /// </summary>
    public void QuitGame()
    {
        SaveGame();
        
        #if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
        #else
        Application.Quit();
        #endif
    }
    
    /// <summary>
    /// 씬 전환
    /// </summary>
    public void LoadScene(string sceneName)
    {
        SaveGame();
        SceneManager.LoadScene(sceneName);
    }
    
    private void OnApplicationPause(bool pause)
    {
        // 모바일에서 백그라운드로 갈 때 자동 저장
        if (pause)
        {
            SaveGame();
        }
    }
    
    private void OnApplicationQuit()
    {
        // 게임 종료 시 자동 저장
        SaveGame();
    }
    
    // Getters
    public Character GetPlayer() => player;
    public DataManager GetDataManager() => dataManager;
    public BattleManager GetBattleManager() => battleManager;
    public SaveManager GetSaveManager() => saveManager;
    public bool IsGamePaused() => isGamePaused;
    public float GetGamePlayTime() => gamePlayTime;
}
