using UnityEngine;

/// <summary>
/// 몬스터 데이터 (CSV에서 로드)
/// </summary>
[System.Serializable]
public class MonsterData
{
    public int monsterId;
    public string monsterName;
    public string monsterType;      // Beast, Construct, Demon, etc.
    public string monsterSubType;   // Wolf, Golem, Imp, etc.
    public int monsterClass;        // 1, 2, 3 (등급)
    public string spawnGrade;       // normal, elite, boss
    
    public float hp;
    public float attack;
    public float defense;
    public float attackSpeed;
    public int expReward;
    public int goldMin;
    public int goldMax;
    
    // 드랍 정보
    public float equipDropChance;
    public int fieldLevel;
}

/// <summary>
/// 몬스터
/// </summary>
public class Monster : Entity
{
    [Header("Monster Specific")]
    public MonsterData monsterData;
    public int fieldLevel = 1;
    public string spawnGrade = "normal"; // normal, elite, boss
    
    [Header("Rewards")]
    public int expReward = 50;
    public int goldReward = 10;
    
    private SkillUser skillUser;
    private Entity currentTarget;
    
    protected override void Awake()
    {
        base.Awake();
        skillUser = GetComponent<SkillUser>();
    }
    
    /// <summary>
    /// 몬스터 데이터로 초기화
    /// </summary>
    public void Initialize(MonsterData data)
    {
        monsterData = data;
        
        // 기본 정보
        entityName = data.monsterName;
        level = fieldLevel; // 필드 레벨 = 몬스터 레벨
        
        // 스탯 설정
        maxHp = data.hp;
        currentHp = maxHp;
        attackDamage = data.attack;
        defense = data.defense;
        attackSpeed = data.attackSpeed;
        
        // 보상 설정
        expReward = data.expReward;
        goldReward = Random.Range(data.goldMin, data.goldMax + 1);
        
        // 스폰 등급에 따른 보정
        ApplySpawnGradeModifier(data.spawnGrade);
        
        // 스킬 설정
        SetupSkills(data.monsterType);
    }
    
    /// <summary>
    /// 스폰 등급에 따른 스탯 보정
    /// </summary>
    private void ApplySpawnGradeModifier(string grade)
    {
        spawnGrade = grade;
        
        float statMultiplier = 1f;
        float rewardMultiplier = 1f;
        
        switch (grade.ToLower())
        {
            case "normal":
                statMultiplier = 1f;
                rewardMultiplier = 1f;
                break;
                
            case "elite":
                statMultiplier = 2f;
                rewardMultiplier = 3f;
                entityName = $"정예 {entityName}";
                break;
                
            case "boss":
                statMultiplier = 5f;
                rewardMultiplier = 10f;
                entityName = $"보스 {entityName}";
                break;
        }
        
        // 스탯 적용
        maxHp *= statMultiplier;
        currentHp = maxHp;
        attackDamage *= statMultiplier;
        defense *= statMultiplier;
        
        // 보상 적용
        expReward = Mathf.RoundToInt(expReward * rewardMultiplier);
        goldReward = Mathf.RoundToInt(goldReward * rewardMultiplier);
    }
    
    /// <summary>
    /// 몬스터 타입에 따른 스킬 설정
    /// </summary>
    private void SetupSkills(string type)
    {
        if (skillUser == null) return;
        
        switch (type.ToLower())
        {
            case "beast":
                // 야수: 빠른 공격
                skillUser.AddSkill(new Skill("물어뜯기", SkillType.Damage, 0.15f, 1.5f));
                break;
                
            case "construct":
                // 구조물: 강력한 일격
                skillUser.AddSkill(new Skill("강타", SkillType.Damage, 0.1f, 2.5f));
                break;
                
            case "demon":
                // 악마: 마법 공격
                skillUser.AddSkill(new Skill("암흑 화염", SkillType.Damage, 0.12f, 2.0f));
                break;
                
            case "undead":
                // 언데드: 흡혈
                skillUser.AddSkill(new Skill("생명력 흡수", SkillType.Damage, 0.1f, 1.5f));
                break;
        }
        
        // 보스는 추가 스킬
        if (spawnGrade == "boss")
        {
            skillUser.AddSkill(new Skill("광폭화", SkillType.Buff, 0.08f, 0f, 1.5f));
        }
    }
    
    /// <summary>
    /// 공격 대상 설정
    /// </summary>
    public void SetTarget(Entity target)
    {
        currentTarget = target;
    }
    
    /// <summary>
    /// 공격 수행
    /// </summary>
    protected override void PerformAttack()
    {
        if (currentTarget == null || currentTarget.IsDead)
        {
            return;
        }
        
        OnAttack?.Invoke();
        
        // 스킬 발동 시도
        if (skillUser != null && skillUser.TryActivateSkill(currentTarget))
        {
            return;
        }
        
        // 일반 공격
        float damage = CalculateDamage();
        currentTarget.TakeDamage(damage, this);
    }
    
    /// <summary>
    /// 사망 처리 (보상 지급)
    /// </summary>
    protected override void Die()
    {
        base.Die();
        
        // 보상은 BattleManager에서 처리
    }
    
    /// <summary>
    /// 몬스터 스코어 계산 (아이템 드랍용)
    /// </summary>
    public float GetMonsterScore()
    {
        // CSV에서 로드한 계수 사용 (여기서는 하드코딩)
        float baseScore = level + (fieldLevel * 2f);
        float levelMultiplier = 1 + (level * 0.01f);
        float gradeMultiplier = monsterData?.monsterClass ?? 1;
        
        float spawnMultiplier = 1f;
        switch (spawnGrade.ToLower())
        {
            case "normal": spawnMultiplier = 1f; break;
            case "elite": spawnMultiplier = 3f; break;
            case "boss": spawnMultiplier = 5f; break;
        }
        
        return baseScore * levelMultiplier * gradeMultiplier * spawnMultiplier;
    }
}
