using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 장비 타입
/// </summary>
public enum EquipmentType
{
    Weapon,
    Armor,
    Helmet,
    Gloves,
    Boots
}

/// <summary>
/// 아이템 등급
/// </summary>
public enum ItemRarity
{
    Normal,     // 일반 (흰색)
    Magic,      // 매직 (파란색) - 접두사 1개
    Rare,       // 레어 (노란색) - 접두사 + 접미사
    Unique      // 유니크 (주황색) - 고정 옵션
}

/// <summary>
/// 스탯 타입
/// </summary>
public enum StatType
{
    Hp,
    AtkDamage,
    Defense,
    AtkSpeed,
    Evasion,
    CriticalChance,
    CriticalDamage,
    LifeSteal,
    
    // 특수 스탯
    AddDamageToUndead,
    AddDamageToBigUnit,
    AddDamageToDemon,
}

/// <summary>
/// 아이템 옵션
/// </summary>
[Serializable]
public class ItemOption
{
    public StatType statType;
    public float value;
    public bool isPercentile; // true면 %, false면 고정값
    public string targetType; // "undead", "big_unit" 등 (특수 옵션용)
    
    public ItemOption(StatType type, float val, bool percentile = false, string target = "")
    {
        statType = type;
        value = val;
        isPercentile = percentile;
        targetType = target;
    }
    
    public string GetDisplayText()
    {
        string prefix = value > 0 ? "+" : "";
        string suffix = isPercentile ? "%" : "";
        string targetText = string.IsNullOrEmpty(targetType) ? "" : $" (대 {targetType})";
        
        return $"{statType}: {prefix}{value}{suffix}{targetText}";
    }
}

/// <summary>
/// 장비 아이템
/// </summary>
[Serializable]
public class Equipment
{
    // 기본 정보
    public int itemId;
    public string itemName;
    public EquipmentType equipmentType;
    public ItemRarity rarity;
    public int itemLevel;
    
    // 베이스 아이템 정보
    public string baseItemName;
    public float quality; // 0.0 ~ 1.0 (아이템 품질)
    
    // 접두/접미사
    public string prefix;
    public string suffix;
    
    // 옵션들
    public List<ItemOption> options = new List<ItemOption>();
    
    // 베이스 스탯 (무기의 기본 공격력 등)
    public float baseMinDamage;
    public float baseMaxDamage;
    public float baseDefense;
    
    /// <summary>
    /// 아이템 이름 생성 (접두사 + 베이스 + 접미사)
    /// </summary>
    public string GetFullName()
    {
        string fullName = "";
        
        if (!string.IsNullOrEmpty(prefix))
            fullName += prefix + " ";
        
        fullName += baseItemName;
        
        if (!string.IsNullOrEmpty(suffix))
            fullName += " " + suffix;
        
        return fullName;
    }
    
    /// <summary>
    /// 아이템 설명 생성
    /// </summary>
    public string GetDescription()
    {
        string desc = $"[{rarity}] {GetFullName()}\n";
        desc += $"레벨: {itemLevel}\n";
        desc += $"품질: {(quality * 100):F1}%\n";
        desc += "\n<옵션>\n";
        
        foreach (var option in options)
        {
            desc += option.GetDisplayText() + "\n";
        }
        
        return desc;
    }
    
    /// <summary>
    /// 옵션 추가
    /// </summary>
    public void AddOption(ItemOption option)
    {
        options.Add(option);
    }
    
    /// <summary>
    /// 특정 스탯의 총 합계 계산
    /// </summary>
    public float GetTotalStatValue(StatType statType)
    {
        float total = 0f;
        
        foreach (var option in options)
        {
            if (option.statType == statType)
            {
                total += option.value;
            }
        }
        
        return total;
    }
    
    /// <summary>
    /// 아이템 가치 계산 (판매가 등)
    /// </summary>
    public int GetValue()
    {
        int baseValue = itemLevel * 10;
        
        // 등급에 따른 배수
        int rarityMultiplier = rarity switch
        {
            ItemRarity.Normal => 1,
            ItemRarity.Magic => 3,
            ItemRarity.Rare => 10,
            ItemRarity.Unique => 50,
            _ => 1
        };
        
        // 품질 보너스
        float qualityBonus = 1f + quality;
        
        return Mathf.RoundToInt(baseValue * rarityMultiplier * qualityBonus);
    }
}

/// <summary>
/// 장비 빌더 (아이템 생성용)
/// </summary>
public class EquipmentBuilder
{
    private Equipment equipment = new Equipment();
    
    public EquipmentBuilder(int id, string baseName, EquipmentType type)
    {
        equipment.itemId = id;
        equipment.baseItemName = baseName;
        equipment.equipmentType = type;
    }
    
    public EquipmentBuilder SetLevel(int level)
    {
        equipment.itemLevel = level;
        return this;
    }
    
    public EquipmentBuilder SetRarity(ItemRarity rarity)
    {
        equipment.rarity = rarity;
        return this;
    }
    
    public EquipmentBuilder SetQuality(float quality)
    {
        equipment.quality = Mathf.Clamp01(quality);
        return this;
    }
    
    public EquipmentBuilder SetPrefix(string prefix)
    {
        equipment.prefix = prefix;
        return this;
    }
    
    public EquipmentBuilder SetSuffix(string suffix)
    {
        equipment.suffix = suffix;
        return this;
    }
    
    public EquipmentBuilder AddOption(StatType statType, float value, bool isPercentile = false, string target = "")
    {
        equipment.AddOption(new ItemOption(statType, value, isPercentile, target));
        return this;
    }
    
    public EquipmentBuilder SetBaseDamage(float min, float max)
    {
        equipment.baseMinDamage = min;
        equipment.baseMaxDamage = max;
        return this;
    }
    
    public EquipmentBuilder SetBaseDefense(float defense)
    {
        equipment.baseDefense = defense;
        return this;
    }
    
    public Equipment Build()
    {
        return equipment;
    }
}
