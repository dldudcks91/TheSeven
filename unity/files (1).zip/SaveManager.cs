using System;
using System.IO;
using UnityEngine;

/// <summary>
/// 저장 데이터 구조
/// </summary>
[Serializable]
public class SaveData
{
    // 플레이어 정보
    public string playerName;
    public int level;
    public int exp;
    public int expToNextLevel;
    public int gold;
    public float currentHp;
    public float maxHp;
    
    // 플레이어 스탯
    public float attackDamage;
    public float defense;
    public float attackSpeed;
    public float evasion;
    public float criticalChance;
    public float criticalDamage;
    
    // 진행 정보
    public int currentFieldLevel;
    public int currentMonsterId;
    
    // 게임 시간
    public float playTime;
    public string saveDateTime;
    
    // 장비 (간단히 ID만 저장)
    public int weaponId;
    public int armorId;
    public int helmetId;
    public int glovesId;
    public int bootsId;
    
    // TODO: 인벤토리 아이템들
}

/// <summary>
/// 게임 저장/로드 관리자
/// </summary>
public class SaveManager : MonoBehaviour
{
    private const string SAVE_FILE_NAME = "savegame.json";
    private string saveFilePath;
    
    private void Awake()
    {
        // 저장 파일 경로 설정
        saveFilePath = Path.Combine(Application.persistentDataPath, SAVE_FILE_NAME);
        Debug.Log($"저장 파일 경로: {saveFilePath}");
    }
    
    /// <summary>
    /// 플레이어 데이터 저장
    /// </summary>
    public void SavePlayerData(Character player)
    {
        if (player == null)
        {
            Debug.LogError("플레이어가 null입니다!");
            return;
        }
        
        SaveData saveData = new SaveData
        {
            // 기본 정보
            playerName = player.entityName,
            level = player.level,
            exp = player.exp,
            expToNextLevel = player.expToNextLevel,
            gold = player.gold,
            currentHp = player.currentHp,
            maxHp = player.maxHp,
            
            // 스탯
            attackDamage = player.attackDamage,
            defense = player.defense,
            attackSpeed = player.attackSpeed,
            evasion = player.evasion,
            criticalChance = player.criticalChance,
            criticalDamage = player.criticalDamage,
            
            // 진행 정보
            currentFieldLevel = 1, // TODO: 실제 필드 레벨
            currentMonsterId = 1,  // TODO: 현재 몬스터 ID
            
            // 게임 시간
            playTime = GameManager.Instance?.GetGamePlayTime() ?? 0f,
            saveDateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
            
            // 장비
            weaponId = player.weapon?.itemId ?? 0,
            armorId = player.armor?.itemId ?? 0,
            helmetId = player.helmet?.itemId ?? 0,
            glovesId = player.gloves?.itemId ?? 0,
            bootsId = player.boots?.itemId ?? 0
        };
        
        // JSON으로 변환
        string json = JsonUtility.ToJson(saveData, true);
        
        // 파일에 저장
        try
        {
            File.WriteAllText(saveFilePath, json);
            Debug.Log($"저장 완료: {saveFilePath}");
        }
        catch (Exception e)
        {
            Debug.LogError($"저장 실패: {e.Message}");
        }
    }
    
    /// <summary>
    /// 플레이어 데이터 로드
    /// </summary>
    public void LoadPlayerData(Character player)
    {
        if (player == null)
        {
            Debug.LogError("플레이어가 null입니다!");
            return;
        }
        
        if (!File.Exists(saveFilePath))
        {
            Debug.LogWarning("저장 파일이 없습니다.");
            return;
        }
        
        try
        {
            // 파일 읽기
            string json = File.ReadAllText(saveFilePath);
            
            // JSON 파싱
            SaveData saveData = JsonUtility.FromJson<SaveData>(json);
            
            // 플레이어 데이터 복원
            player.entityName = saveData.playerName;
            player.level = saveData.level;
            player.exp = saveData.exp;
            player.expToNextLevel = saveData.expToNextLevel;
            player.gold = saveData.gold;
            player.currentHp = saveData.currentHp;
            player.maxHp = saveData.maxHp;
            
            player.attackDamage = saveData.attackDamage;
            player.defense = saveData.defense;
            player.attackSpeed = saveData.attackSpeed;
            player.evasion = saveData.evasion;
            player.criticalChance = saveData.criticalChance;
            player.criticalDamage = saveData.criticalDamage;
            
            // TODO: 장비 복원
            // player.weapon = LoadEquipment(saveData.weaponId);
            
            Debug.Log($"로드 완료: {saveData.saveDateTime}");
        }
        catch (Exception e)
        {
            Debug.LogError($"로드 실패: {e.Message}");
        }
    }
    
    /// <summary>
    /// 저장 데이터 존재 여부
    /// </summary>
    public bool HasSaveData()
    {
        return File.Exists(saveFilePath);
    }
    
    /// <summary>
    /// 저장 데이터 삭제
    /// </summary>
    public void DeleteSaveData()
    {
        if (File.Exists(saveFilePath))
        {
            File.Delete(saveFilePath);
            Debug.Log("저장 데이터 삭제 완료");
        }
    }
    
    /// <summary>
    /// 저장 정보 가져오기 (로드 화면용)
    /// </summary>
    public SaveData GetSaveInfo()
    {
        if (!File.Exists(saveFilePath))
        {
            return null;
        }
        
        try
        {
            string json = File.ReadAllText(saveFilePath);
            return JsonUtility.FromJson<SaveData>(json);
        }
        catch (Exception e)
        {
            Debug.LogError($"저장 정보 로드 실패: {e.Message}");
            return null;
        }
    }
}
