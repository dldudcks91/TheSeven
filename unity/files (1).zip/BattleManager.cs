using System;
using System.Collections;
using UnityEngine;

/// <summary>
/// 전투 상태
/// </summary>
public enum BattleState
{
    Idle,       // 대기
    Fighting,   // 전투 중
    Victory,    // 승리
    Defeat      // 패배
}

/// <summary>
/// 전투 관리자
/// </summary>
public class BattleManager : MonoBehaviour
{
    public static BattleManager Instance { get; private set; }
    
    [Header("Battle Settings")]
    public float battleCheckInterval = 0.1f; // 전투 상태 체크 간격
    
    [Header("References")]
    public Character player;
    public Monster currentMonster;
    
    // 전투 상태
    private BattleState currentState = BattleState.Idle;
    
    // 이벤트
    public event Action<Monster> OnBattleStart;
    public event Action<Monster> OnMonsterDefeated;
    public event Action OnPlayerDefeated;
    public event Action<BattleState> OnBattleStateChanged;
    
    private void Awake()
    {
        // 싱글톤 설정
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
            return;
        }
    }
    
    private void Start()
    {
        // 플레이어 찾기
        if (player == null)
        {
            player = FindObjectOfType<Character>();
        }
        
        if (player != null)
        {
            player.OnDeath += OnPlayerDeath;
        }
    }
    
    /// <summary>
    /// 전투 시작
    /// </summary>
    public void StartBattle(Monster monster)
    {
        if (monster == null)
        {
            Debug.LogError("몬스터가 null입니다!");
            return;
        }
        
        currentMonster = monster;
        
        // 전투 준비
        player.ResetForBattle();
        monster.Revive();
        
        // 타겟 설정
        player.SetTarget(monster);
        monster.SetTarget(player);
        
        // 이벤트 등록
        monster.OnDeath += OnMonsterDeath;
        
        // 전투 시작
        SetBattleState(BattleState.Fighting);
        OnBattleStart?.Invoke(monster);
        
        Debug.Log($"===== 전투 시작: {player.entityName} vs {monster.entityName} =====");
    }
    
    /// <summary>
    /// 전투 종료
    /// </summary>
    public void EndBattle()
    {
        if (currentMonster != null)
        {
            currentMonster.OnDeath -= OnMonsterDeath;
            currentMonster = null;
        }
        
        SetBattleState(BattleState.Idle);
    }
    
    /// <summary>
    /// 몬스터 사망 처리
    /// </summary>
    private void OnMonsterDeath(Entity entity)
    {
        Monster monster = entity as Monster;
        if (monster == null) return;
        
        SetBattleState(BattleState.Victory);
        
        Debug.Log($"===== 승리! {monster.entityName} 처치 =====");
        
        // 보상 지급
        GiveRewards(monster);
        
        // 이벤트 발생
        OnMonsterDefeated?.Invoke(monster);
        
        // 다음 전투 준비
        StartCoroutine(PrepareNextBattle());
    }
    
    /// <summary>
    /// 플레이어 사망 처리
    /// </summary>
    private void OnPlayerDeath(Entity entity)
    {
        SetBattleState(BattleState.Defeat);
        
        Debug.Log("===== 패배... =====");
        
        OnPlayerDefeated?.Invoke();
        
        // 부활 처리 (Idle 게임이므로 자동 부활)
        StartCoroutine(RevivePlayer());
    }
    
    /// <summary>
    /// 보상 지급
    /// </summary>
    private void GiveRewards(Monster monster)
    {
        // 경험치
        player.GainExp(monster.expReward);
        
        // 골드
        player.GainGold(monster.goldReward);
        
        // 아이템 드랍 시도
        TryDropItem(monster);
    }
    
    /// <summary>
    /// 아이템 드랍 시도
    /// </summary>
    private void TryDropItem(Monster monster)
    {
        // 몬스터 스코어 계산
        float monsterScore = monster.GetMonsterScore();
        
        // 드랍 횟수 결정 (스폰 등급에 따라)
        int dropAttempts = 1;
        switch (monster.spawnGrade.ToLower())
        {
            case "normal": dropAttempts = 1; break;
            case "elite": dropAttempts = 3; break;
            case "boss": dropAttempts = 5; break;
        }
        
        // 여러 번 드랍 시도
        for (int i = 0; i < dropAttempts; i++)
        {
            // TODO: ItemDropManager를 통해 실제 아이템 생성
            // float dropChance = UnityEngine.Random.value;
            // if (dropChance < monster.monsterData.equipDropChance)
            // {
            //     Item droppedItem = ItemDropManager.Instance.GenerateItem(monsterScore);
            //     player.AddItemToInventory(droppedItem);
            // }
            
            Debug.Log($"아이템 드랍 시도 {i + 1}/{dropAttempts} (Monster Score: {monsterScore})");
        }
    }
    
    /// <summary>
    /// 다음 전투 준비
    /// </summary>
    private IEnumerator PrepareNextBattle()
    {
        yield return new WaitForSeconds(1f);
        
        // 다음 몬스터 생성
        // TODO: 실제로는 DataManager에서 다음 몬스터 정보를 가져와야 함
        SpawnNextMonster();
    }
    
    /// <summary>
    /// 플레이어 부활
    /// </summary>
    private IEnumerator RevivePlayer()
    {
        yield return new WaitForSeconds(2f);
        
        player.Revive();
        Debug.Log("플레이어 부활!");
        
        // 전투 재시작
        if (currentMonster != null)
        {
            StartBattle(currentMonster);
        }
    }
    
    /// <summary>
    /// 다음 몬스터 생성
    /// </summary>
    private void SpawnNextMonster()
    {
        // TODO: DataManager를 통해 다음 몬스터 데이터 로드
        // 지금은 테스트용으로 간단히 처리
        
        if (currentMonster != null)
        {
            // 기존 몬스터 정보로 새 몬스터 생성
            MonsterData nextData = currentMonster.monsterData;
            
            // 레벨을 조금씩 올림
            nextData.hp *= 1.1f;
            nextData.attack *= 1.1f;
            nextData.defense *= 1.05f;
            nextData.expReward = Mathf.RoundToInt(nextData.expReward * 1.1f);
            
            currentMonster.Initialize(nextData);
            StartBattle(currentMonster);
        }
    }
    
    /// <summary>
    /// 전투 상태 변경
    /// </summary>
    private void SetBattleState(BattleState newState)
    {
        if (currentState == newState) return;
        
        currentState = newState;
        OnBattleStateChanged?.Invoke(newState);
        
        Debug.Log($"전투 상태: {newState}");
    }
    
    /// <summary>
    /// 전투 일시정지
    /// </summary>
    public void PauseBattle()
    {
        Time.timeScale = 0f;
    }
    
    /// <summary>
    /// 전투 재개
    /// </summary>
    public void ResumeBattle()
    {
        Time.timeScale = 1f;
    }
    
    // Getter
    public BattleState GetBattleState() => currentState;
    public bool IsFighting() => currentState == BattleState.Fighting;
}
