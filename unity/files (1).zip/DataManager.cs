using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;

/// <summary>
/// CSV 데이터를 로드하고 관리하는 매니저
/// </summary>
public class DataManager : MonoBehaviour
{
    [Header("CSV Paths")]
    public string dataFolderPath = "Data"; // Resources 폴더 내 경로
    
    // 데이터 딕셔너리
    private Dictionary<int, MonsterData> monsterDataDict = new Dictionary<int, MonsterData>();
    private Dictionary<int, EquipmentBaseData> equipmentBaseDict = new Dictionary<int, EquipmentBaseData>();
    private Dictionary<string, PrefixData> prefixDataDict = new Dictionary<string, PrefixData>();
    
    // 설정 데이터
    private Dictionary<string, float> monsterScoreConfig = new Dictionary<string, float>();
    private List<RarityConfig> rarityConfigs = new List<RarityConfig>();
    
    /// <summary>
    /// 모든 데이터 로드
    /// </summary>
    public void LoadAllData()
    {
        Debug.Log("===== 데이터 로딩 시작 =====");
        
        // 각 CSV 파일 로드
        LoadMonsterData();
        LoadEquipmentBaseData();
        LoadPrefixData();
        LoadMonsterScoreConfig();
        LoadRarityConfig();
        
        Debug.Log("===== 데이터 로딩 완료 =====");
    }
    
    /// <summary>
    /// 몬스터 데이터 로드
    /// </summary>
    private void LoadMonsterData()
    {
        TextAsset csvFile = Resources.Load<TextAsset>($"{dataFolderPath}/monster-info");
        if (csvFile == null)
        {
            Debug.LogWarning("monster-info.csv 파일을 찾을 수 없습니다. 테스트 데이터를 생성합니다.");
            CreateTestMonsterData();
            return;
        }
        
        string[] lines = csvFile.text.Split('\n');
        
        // 헤더 스킵
        for (int i = 1; i < lines.Length; i++)
        {
            if (string.IsNullOrEmpty(lines[i].Trim())) continue;
            
            string[] values = lines[i].Split(',');
            
            MonsterData data = new MonsterData
            {
                monsterId = int.Parse(values[0]),
                monsterName = values[1],
                monsterType = values[2],
                monsterSubType = values[3],
                monsterClass = int.Parse(values[4]),
                hp = float.Parse(values[5]),
                attack = float.Parse(values[6]),
                defense = float.Parse(values[7]),
                attackSpeed = float.Parse(values[8]),
                expReward = int.Parse(values[9]),
                goldMin = 5,
                goldMax = 15,
                equipDropChance = 0.3f,
                fieldLevel = 1,
                spawnGrade = "normal"
            };
            
            monsterDataDict[data.monsterId] = data;
        }
        
        Debug.Log($"몬스터 데이터 {monsterDataDict.Count}개 로드 완료");
    }
    
    /// <summary>
    /// 장비 베이스 데이터 로드
    /// </summary>
    private void LoadEquipmentBaseData()
    {
        // TODO: equipment-base.csv 파일 로드
        Debug.Log("장비 베이스 데이터 로드 (미구현)");
    }
    
    /// <summary>
    /// 접두사 데이터 로드
    /// </summary>
    private void LoadPrefixData()
    {
        // TODO: equipment-prefix.csv 파일 로드
        Debug.Log("접두사 데이터 로드 (미구현)");
    }
    
    /// <summary>
    /// 몬스터 스코어 설정 로드
    /// </summary>
    private void LoadMonsterScoreConfig()
    {
        TextAsset csvFile = Resources.Load<TextAsset>($"{dataFolderPath}/monster-score-config");
        if (csvFile == null)
        {
            Debug.LogWarning("monster-score-config.csv 파일을 찾을 수 없습니다. 기본값을 사용합니다.");
            
            // 기본값 설정
            monsterScoreConfig["field_level_multiplier"] = 2.0f;
            monsterScoreConfig["level_growth_rate"] = 0.01f;
            monsterScoreConfig["min_base_score"] = 5f;
            monsterScoreConfig["score_variance"] = 0.05f;
            return;
        }
        
        string[] lines = csvFile.text.Split('\n');
        
        for (int i = 1; i < lines.Length; i++)
        {
            if (string.IsNullOrEmpty(lines[i].Trim())) continue;
            
            string[] values = lines[i].Split(',');
            string paramName = values[0];
            float value = float.Parse(values[1]);
            
            monsterScoreConfig[paramName] = value;
        }
        
        Debug.Log($"몬스터 스코어 설정 로드 완료: {monsterScoreConfig.Count}개");
    }
    
    /// <summary>
    /// 아이템 등급 설정 로드
    /// </summary>
    private void LoadRarityConfig()
    {
        TextAsset csvFile = Resources.Load<TextAsset>($"{dataFolderPath}/item-rarity-config");
        if (csvFile == null)
        {
            Debug.LogWarning("item-rarity-config.csv 파일을 찾을 수 없습니다. 기본값을 사용합니다.");
            
            // 기본값 설정
            rarityConfigs.Add(new RarityConfig
            {
                rarity = ItemRarity.Normal,
                minScore = 0,
                maxScore = 50,
                baseWeight = 1000
            });
            return;
        }
        
        string[] lines = csvFile.text.Split('\n');
        
        for (int i = 1; i < lines.Length; i++)
        {
            if (string.IsNullOrEmpty(lines[i].Trim())) continue;
            
            string[] values = lines[i].Split(',');
            
            RarityConfig config = new RarityConfig
            {
                rarity = ParseRarity(values[0]),
                minScore = float.Parse(values[2]),
                maxScore = float.Parse(values[3]),
                baseWeight = float.Parse(values[4])
            };
            
            rarityConfigs.Add(config);
        }
        
        Debug.Log($"아이템 등급 설정 로드 완료: {rarityConfigs.Count}개");
    }
    
    /// <summary>
    /// 테스트용 몬스터 데이터 생성
    /// </summary>
    private void CreateTestMonsterData()
    {
        // Gray Wolf
        monsterDataDict[1] = new MonsterData
        {
            monsterId = 1,
            monsterName = "Gray Wolf",
            monsterType = "Beast",
            monsterSubType = "Wolf",
            monsterClass = 1,
            hp = 250,
            attack = 30,
            defense = 10,
            attackSpeed = 1.2f,
            expReward = 50,
            goldMin = 5,
            goldMax = 15,
            equipDropChance = 0.3f,
            fieldLevel = 1,
            spawnGrade = "normal"
        };
        
        // Alpha Wolf
        monsterDataDict[2] = new MonsterData
        {
            monsterId = 2,
            monsterName = "Alpha Wolf",
            monsterType = "Beast",
            monsterSubType = "Wolf",
            monsterClass = 2,
            hp = 800,
            attack = 60,
            defense = 25,
            attackSpeed = 1.5f,
            expReward = 200,
            goldMin = 20,
            goldMax = 50,
            equipDropChance = 0.5f,
            fieldLevel = 5,
            spawnGrade = "elite"
        };
        
        Debug.Log("테스트용 몬스터 데이터 생성 완료");
    }
    
    /// <summary>
    /// 문자열을 ItemRarity로 변환
    /// </summary>
    private ItemRarity ParseRarity(string rarityStr)
    {
        return rarityStr.ToLower() switch
        {
            "normal" => ItemRarity.Normal,
            "magic" => ItemRarity.Magic,
            "rare" => ItemRarity.Rare,
            "unique" => ItemRarity.Unique,
            _ => ItemRarity.Normal
        };
    }
    
    // ===== Getter 메서드들 =====
    
    public MonsterData GetMonsterData(int monsterId)
    {
        if (monsterDataDict.TryGetValue(monsterId, out MonsterData data))
        {
            return data;
        }
        
        Debug.LogWarning($"몬스터 ID {monsterId}를 찾을 수 없습니다.");
        return null;
    }
    
    public float GetMonsterScoreConfig(string paramName)
    {
        if (monsterScoreConfig.TryGetValue(paramName, out float value))
        {
            return value;
        }
        
        return 0f;
    }
    
    public List<RarityConfig> GetRarityConfigs()
    {
        return rarityConfigs;
    }
    
    public RarityConfig GetRarityConfigForScore(float score)
    {
        var eligible = rarityConfigs
            .Where(r => r.minScore <= score && r.maxScore >= score)
            .ToList();
        
        if (eligible.Count == 0)
        {
            return rarityConfigs.FirstOrDefault();
        }
        
        // 가중치 기반 선택
        float totalWeight = 0f;
        foreach (var config in eligible)
        {
            float scoreRatio = (score - config.minScore) / (config.maxScore - config.minScore);
            totalWeight += config.baseWeight * (0.5f + scoreRatio * 1.5f);
        }
        
        float random = UnityEngine.Random.value * totalWeight;
        float cumulative = 0f;
        
        foreach (var config in eligible)
        {
            float scoreRatio = (score - config.minScore) / (config.maxScore - config.minScore);
            cumulative += config.baseWeight * (0.5f + scoreRatio * 1.5f);
            
            if (random <= cumulative)
            {
                return config;
            }
        }
        
        return eligible.Last();
    }
}

// ===== 데이터 구조체들 =====

[Serializable]
public class EquipmentBaseData
{
    public int itemIdx;
    public string itemBase;
    public string mainGroup;
    public string subGroup;
    public string type;
    public float minDamage;
    public float maxDamage;
    public float speed;
}

[Serializable]
public class PrefixData
{
    public string prefix;
    public string prefixKorean;
    public EquipmentType equipmentType;
    public int weight;
    public StatType stat1;
    public float minStat1;
    public float maxStat1;
    public StatType stat2;
    public float minStat2;
    public float maxStat2;
}

[Serializable]
public class RarityConfig
{
    public ItemRarity rarity;
    public float minScore;
    public float maxScore;
    public float baseWeight;
}
